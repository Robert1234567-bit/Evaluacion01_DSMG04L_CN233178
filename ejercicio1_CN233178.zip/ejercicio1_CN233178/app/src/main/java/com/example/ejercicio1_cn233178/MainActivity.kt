package com.example.ejercicio1_cn233178

import android.media.VolumeShaper
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var nombre :EditText
    private lateinit var nota1  :EditText
    private lateinit var nota2  :EditText
    private lateinit var nota3  :EditText
    private lateinit var nota4  :EditText
    private lateinit var nota5  :EditText
    private lateinit var result: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        nota1 = findViewById(R.id.nota1)
        nota2 = findViewById(R.id.nota2)
        nota3 = findViewById(R.id.nota3)
        nota4 = findViewById(R.id.nota4)
        nota5 = findViewById(R.id.nota5)




    }

    private fun calculate(operation: VolumeShaper.Operation) {
    }

    val input1Text = nota1.text.toString()
    val input2Text = nota2.text.toString()
    val input3Text = nota3.text.toString()
    val input4Text = nota4.text.toString()
    val input5Text = nota5.text.toString()



    }

val num1 = nota1Text.toDouble()
val num2 = nota2Text.toDouble()
var result = 0.0








